1.Are there any requirements for accessing Testing Engine?

There are following requirements:
* System: Windows Operating System Only (please contact us if you need MAC version)
* Latest Java Runtime Environment (JRE 64 bit)

2.How do I use the Testing Engine?
Our Testing Engine does not need to be installed, just unzip it in one step, and then click exe file to run easily.

3.Unable to launch program?
* Do not remove any file path, drag the whole folder to applications folder.
* You need to "unzip" your files at first, then open the exe file directly and bypass security.

